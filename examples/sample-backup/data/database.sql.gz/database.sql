SELECT 1; -- sample
